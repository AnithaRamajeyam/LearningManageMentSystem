package com.cts.learningmanagementsystem.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.learningmanagementsystem.model.Course;

@Repository
public interface CourseRepository extends MongoRepository<Course, String> {

	@Query("{'technology': ?0}")
	List<Course> findCourseByTechnolgy(String technology);

	@Query(value = "{'courseName': ?0}", delete = true)
	void deleteByCourseName(String courseName);
	
	@Query("{'technology': ?0, 'courseDuration': { $gt : ?1, $lt : ?2}}")
	List<Course> findCourseByDuration(String technology, int durationFromRange, int durationToRange);
	

}
