package com.cts.learningmanagementsystem.service;

import java.util.List;

import com.cts.learningmanagementsystem.model.Course;

public interface CourseService {
	
	public List<Course> getAllCourses();

	public List<Course> getCourseByTechnology(String technology);

	public List<Course> getCourseByDuration(String technology, int durationFromRange, int durationToRange);

	public Course saveCourse(Course course);

	public void deleteCourse(String courseName);
}
