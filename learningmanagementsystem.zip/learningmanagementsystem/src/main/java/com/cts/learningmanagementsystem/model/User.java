package com.cts.learningmanagementsystem.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.data.annotation.Id;

import lombok.Data;

@Data
public class User {

	@Id
	public String userId;
	
	@NotBlank(message = "FirstName should not be empty")
	private String firstName;
	
	@NotBlank(message = "LastName should not be empty")
	private String lastName;
	
	@NotBlank(message = "UserName should not be empty")
	private String userName;
	
	@Email(message = "Email should be valid")
	private String email;
	
	@Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$", message = "password should be Alphanumeric and should be atleast 8 characters")
	private String password;
	
	@NotBlank(message = "passowrd should not be empty")
	private String confirmPassword;
	
	@NotNull(message = "ContactNumber should not be empty")
	private Long contactNumber;

}
