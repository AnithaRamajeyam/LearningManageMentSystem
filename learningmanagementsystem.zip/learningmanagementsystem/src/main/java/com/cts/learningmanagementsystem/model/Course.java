package com.cts.learningmanagementsystem.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;

import lombok.Data;

@Data
public class Course {

	@Id
	public String courseId;
	
	@NotBlank(message = "courseName should not be empty")
	@Size(min=20, message = "courseName should be minimum 20 characters")
	private String courseName;
	
	@NotBlank(message = "courseDescription should not be empty")
	@Size(min=100, message = "courseDescription should be minimum 100 characters")
	private String courseDescription;
	
	@NotBlank(message = "courseDuration should not be empty")
	@Pattern(regexp = "^(?=.*[0-9])", message = "Course duration should be numeric")
	private int courseDuration;
	
	@NotBlank(message = "technology should not be empty")
	private String technology;
	
	@NotBlank(message = "launchUrl should not be empty")
	private String launchUrl;
	
}
