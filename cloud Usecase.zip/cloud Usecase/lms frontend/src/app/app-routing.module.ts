import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CourseByDurationComponent } from './course/course-by-duration/course-by-duration.component';
import { CourseByTechnologyComponent } from './course/course-by-technology/course-by-technology.component';
import { ViewCoursesComponent } from './course/view-courses/view-courses.component';
import { NavbarComponent } from './navbar/navbar.component';

const routes: Routes = [
  { path: '', component: NavbarComponent },
  { path: 'all-courses', component: ViewCoursesComponent },
  { path: 'view-courses-duration', component: CourseByDurationComponent },
  { path: 'view-courses-technology', component: CourseByTechnologyComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
