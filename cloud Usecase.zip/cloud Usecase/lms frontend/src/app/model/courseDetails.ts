export class CourseDetails{

    technology!: string;
    durationFromRange!: number;
    durationToRange!: number;
}
