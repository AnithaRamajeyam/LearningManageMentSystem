import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Course } from 'src/app/model/course';
import { CourseDetails } from 'src/app/model/courseDetails';
import { CourseServiceService } from 'src/app/service/course-service.service';

@Component({
  selector: 'app-course-by-duration',
  templateUrl: './course-by-duration.component.html',
  styleUrls: ['./course-by-duration.component.css']
})
export class CourseByDurationComponent {
  constructor(private courseService: CourseServiceService,private fb: FormBuilder) { }
  courses: Course[] =[];
  
  searchForm!: FormGroup;
  isCourseAvailble:boolean = false;
  course: CourseDetails = new CourseDetails();
  ngOnInit(): void {
    this.searchForm = this.fb.group({
      technology: [''],
      durationFromRange: [''],
      durationToRange: ['']
    })
  }

  search() {
    if (this.searchForm.valid) {
      this.course = Object.assign(this.searchForm.value)
      console.log(this.course.technology);
      console.log(this.course.durationFromRange);
      
      console.log(this.course.durationToRange);
      this.courseService.getCourseByDuration(this.course.technology,this.course.durationFromRange,this.course.durationToRange).subscribe(data => { this.courses = data,
        this.isCourseAvailble =true }
      );
    }
  }

}
