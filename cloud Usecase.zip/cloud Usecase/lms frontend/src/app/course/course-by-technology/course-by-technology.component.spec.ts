import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseByTechnologyComponent } from './course-by-technology.component';

describe('CourseByTechnologyComponent', () => {
  let component: CourseByTechnologyComponent;
  let fixture: ComponentFixture<CourseByTechnologyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseByTechnologyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CourseByTechnologyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
