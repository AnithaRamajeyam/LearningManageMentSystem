import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Course } from 'src/app/model/course';
import { CourseServiceService } from 'src/app/service/course-service.service';

@Component({
  selector: 'app-course-by-technology',
  templateUrl: './course-by-technology.component.html',
  styleUrls: ['./course-by-technology.component.css']
})
export class CourseByTechnologyComponent {
  constructor(private courseService: CourseServiceService,private fb: FormBuilder) { }
  courses: Course[] =[];
  
  searchForm!: FormGroup;
  isCourseAvailble:boolean = false;
  course: Course = new Course();
  ngOnInit(): void {
    this.searchForm = this.fb.group({
      technology: ['']
    })
  }

  search() {
    if (this.searchForm.valid) {
      this.course = Object.assign(this.searchForm.value)
      this.courseService.getCourseByTechnology(this.course.technology).subscribe(data => { this.courses = data;
      this.isCourseAvailble =true }
      );
    }
  }
}