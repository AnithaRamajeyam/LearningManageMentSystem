import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Course } from '../model/course';

@Injectable({
  providedIn: 'root'
})
export class CourseServiceService {

  applicationUrl = "https://jb4lq35wr6.execute-api.us-east-1.amazonaws.com/lms/api/v1.0/lms";
  constructor(private httpClient: HttpClient) { }
  public saveCourse(course: any) {
    return this.httpClient.post<Course>(this.applicationUrl + "/courses/add", course);
  }

  public getCourseByDuration(technology: any, durationFromRange: any, durationToRange: any) {
    return this.httpClient.get<Course[]>(this.applicationUrl + "/courses/get/" + technology +"/"+ durationFromRange +"/"+ durationToRange);
  }

  public getCourseByTechnology(technology: any) {
    return this.httpClient.get<Course[]>(this.applicationUrl + "/courses/info/" + technology);
  }
  public getAllCourses() {
    return this.httpClient.get<Course[]>(this.applicationUrl + "/courses/getall");
  }
}
