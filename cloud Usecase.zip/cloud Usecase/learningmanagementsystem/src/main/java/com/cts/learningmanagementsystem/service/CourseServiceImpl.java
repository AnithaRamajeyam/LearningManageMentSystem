package com.cts.learningmanagementsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.learningmanagementsystem.model.Course;
import com.cts.learningmanagementsystem.repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository courseRepository;

	@Override
	public List<Course> getAllCourses() {
		List<Course> allTweets = new ArrayList<Course>();
		try {
			allTweets = (List<Course>) courseRepository.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allTweets;
	}

	@Override
	public List<Course> getCourseByTechnology(String technology) {
		return courseRepository.findByTechnology(technology);
	}

	@Override
	public List<Course> getCourseByDuration(String technology, int durationFromRange, int durationToRange) {
		System.out.println(technology);
		System.out.println(durationFromRange);
		System.out.println(durationToRange);
		
		List<Course> list=courseRepository.findByTechnology(technology);
		List<Course> fliteredList = new ArrayList<Course>();
		for(Course course: list) {
			if(course.getCourseDuration()>durationFromRange &&course.getCourseDuration()<durationToRange){
				fliteredList.add(course);
			}
		}
		return fliteredList;
	}

	@Override
	public Course saveCourse(Course course) {
		Course savedCourse = new Course();
		try {
			if (course != null) {
				savedCourse = courseRepository.save(course);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return savedCourse;
	}

	@Override
	public void deleteCourse(String courseName) {
		// TODO Auto-generated method stub
		courseRepository.deleteByCourseName(courseName);
	}
}
