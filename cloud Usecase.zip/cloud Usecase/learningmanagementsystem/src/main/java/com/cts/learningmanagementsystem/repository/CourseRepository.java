package com.cts.learningmanagementsystem.repository;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.cts.learningmanagementsystem.model.Course;

@EnableScan
@Repository
public interface CourseRepository extends PagingAndSortingRepository<Course, String> {

	List<Course> findByTechnology(String technology);

	void deleteByCourseName(String courseName);
	
}
