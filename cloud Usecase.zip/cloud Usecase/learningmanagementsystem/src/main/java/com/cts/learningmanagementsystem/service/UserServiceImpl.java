package com.cts.learningmanagementsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.learningmanagementsystem.model.User;
import com.cts.learningmanagementsystem.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public User registerUser(User user) {
		User savedUser = new User();
		try {
			if (user != null) {
				savedUser = userRepository.save(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return savedUser;

	}
}
