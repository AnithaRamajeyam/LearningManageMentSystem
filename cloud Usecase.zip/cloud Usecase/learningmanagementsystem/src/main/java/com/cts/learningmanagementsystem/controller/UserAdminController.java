package com.cts.learningmanagementsystem.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.learningmanagementsystem.model.Course;
import com.cts.learningmanagementsystem.model.User;
import com.cts.learningmanagementsystem.service.CourseService;
import com.cts.learningmanagementsystem.service.UserService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1.0/lms")
public class UserAdminController {

	@Autowired
	private UserService userService;

	@Autowired
	private CourseService courseService;

	@PostMapping(path = "/user/register")
	public User registerUser(@Valid @RequestBody User user) {
		return userService.registerUser(user);

	}

	@GetMapping(path = "/courses/getall")
	public List<Course> getAllCourses() {
		return courseService.getAllCourses();

	}

	@GetMapping(path = "/courses/info/{technology}")
	public List<Course> getCourseByTechnology(@PathVariable String technology) {
		return courseService.getCourseByTechnology(technology);
	}

	@GetMapping(path = "/courses/get/{technology}/{durationFromRange}/{durationToRange}")
	public List<Course> getCourseByDuration(@PathVariable String technology, @PathVariable int durationFromRange,
			@PathVariable int durationToRange) {
		return courseService.getCourseByDuration(technology, durationFromRange, durationToRange);
	}

	@PostMapping(path = "/courses/add")
	public Course saveCourse(@RequestBody Course course) {
		return courseService.saveCourse(course);
	}

	@PostMapping(path = "/courses/delete/{courseName}")
	public void deleteCourse(@PathVariable String courseName) {
		 courseService.deleteCourse(courseName);
	}
}
