package com.cts.learningmanagementsystem.service;

import com.cts.learningmanagementsystem.model.User;

public interface UserService {

	public User registerUser(User user);
}
