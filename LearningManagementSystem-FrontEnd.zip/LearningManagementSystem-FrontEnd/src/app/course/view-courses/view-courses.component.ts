import { Component } from '@angular/core';
import { Course } from 'src/app/model/course';
import { CourseServiceService } from 'src/app/service/course-service.service';

@Component({
  selector: 'app-view-courses',
  templateUrl: './view-courses.component.html',
  styleUrls: ['./view-courses.component.css']
})
export class ViewCoursesComponent {
  constructor(private courseService: CourseServiceService) { }
  allCourses: Course[] =[];
  ngOnInit(): void {
    this.courseService.getAllCourses().subscribe(data => {
      if(data!==null){
        this.allCourses=data;
        console.log(this.allCourses);
      }
    });
    
  }
}
