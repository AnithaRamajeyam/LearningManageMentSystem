import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseByDurationComponent } from './course-by-duration.component';

describe('CourseByDurationComponent', () => {
  let component: CourseByDurationComponent;
  let fixture: ComponentFixture<CourseByDurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseByDurationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CourseByDurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
