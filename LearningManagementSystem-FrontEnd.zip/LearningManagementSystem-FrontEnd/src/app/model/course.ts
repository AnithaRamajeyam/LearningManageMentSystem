export class Course{
    courseId!: string;
    courseName!: string;
    courseDescription!: string;
    courseDuration!: number;
    technology!: string;
    launchUrl!: string;
}